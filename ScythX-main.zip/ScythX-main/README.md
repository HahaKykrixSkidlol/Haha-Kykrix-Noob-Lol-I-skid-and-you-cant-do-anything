To run ScythX on your computer run `index.html`.
https://github.com/Kykrix/ScythX/releases/tag/ScythX
